﻿using CarRaceGame;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace RaceTesting
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestPunterFacotry()
        {
            Punter punter = PunterFactory.GetPunter(0);
            Assert.AreEqual(punter.Cash, 50);
        }
    }
}
