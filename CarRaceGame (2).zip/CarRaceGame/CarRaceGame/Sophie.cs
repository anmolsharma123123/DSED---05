﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRaceGame
{
    public class Sophie:Punter
    {
        public Sophie()
        {
            Name = "Sophie";
            Cash = 50;
        }
    }
}
