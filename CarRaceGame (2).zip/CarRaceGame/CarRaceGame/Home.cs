﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRaceGame
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
            stopTimer.Start();
        }

        private void stopTimer_Tick(object sender, EventArgs e)
        {
            stopTimer.Stop();
            Hide();
            GameForm form = new GameForm();
            form.Show();
        }
    }
}
