﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRaceGame
{
    public static class PunterFactory
    {
        public static Punter GetPunter(int id)
        {
            switch (id)
            {
                case 0: return new Charlotte();
                case 1: return new Amelia();
                case 2: return new Sophie();
                default: return null;
            }
        }
    }
}
