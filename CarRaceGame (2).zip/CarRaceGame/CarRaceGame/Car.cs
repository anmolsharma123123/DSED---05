﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRaceGame
{
    public class Car
    {
        public string CarName { set; get; }

        public PictureBox CarPictureBox { set; get; }

        public int FinishPoint { set; get; }

        public void Move(int step)
        {
            CarPictureBox.Location = new Point(CarPictureBox.Location.X + step, CarPictureBox.Location.Y);
        }
        public bool FinishTheRace()
        {
            return CarPictureBox.Location.X > FinishPoint;
        }

        public void Reset()
        {
            CarPictureBox.Location = new Point(2, CarPictureBox.Location.Y);
        }
    }
}
