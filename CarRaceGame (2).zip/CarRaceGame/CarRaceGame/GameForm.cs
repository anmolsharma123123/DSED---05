﻿using RabbitRaceGame.Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CarRaceGame
{
    public partial class GameForm : Form
    {

        Car[] cars;
        Punter[] punters;
        Timer[] timers;
        Car winnerCar;

        public GameForm()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            PictureBox[] pictures = { picture1, picture2, picture3, picture4 };
            cars = new Car[pictures.Length];
            for (int index = 0; index < cars.Length; index++)
            {
                cars[index] = new Car();
                cars[index].CarName = "Car " + (index + 1);
                cars[index].CarPictureBox = pictures[index];
                cars[index].FinishPoint = 690;
            }

            TextBox[] texts = { text1, text2, text3 };
            RadioButton[] radioButtons = { radio1, radio2, radio3 };

            punters = new Punter[texts.Length];
            for (int index = 0; index < punters.Length; index++)
            {
                punters[index] = PunterFactory.GetPunter(index);
                punters[index].PunterRadioButton = radioButtons[index];
                punters[index].PunterRadioButton.Text = punters[index].Name;
                punters[index].PunterTextBox = texts[index];
            }

            npCarNo.Minimum = 1;
            npCarNo.Maximum = cars.Length;
            npCarNo.Value = 1;
        }

        private void btnOperation_Click(object sender, EventArgs e)
        {
            if (btnOperation.Text.Contains("Place"))
            {
                PlaceTheBet();
            }
            else if(btnOperation.Text.Contains("Start"))
            {
                StartRace();
            }
        }

        private void PlaceTheBet()
        {
            int active = 0;
            int totalbet = 0;
            for (int index = 0; index < punters.Length; index++)
            {
                if (!punters[index].Busted())
                {
                    active++;
                    if (punters[index].PunterRadionCheckStatus())
                    {
                        string message = "";
                        if (punters[index].CheckBetStatus())
                        {
                            message = string.Format(" {0} is Already Placed Bet For Car Game...", punters[index].Name);
                        }
                        else
                        {
                            int number = (int)npCarNo.Value;
                            int amount = (int)npBetAmount.Value;
                            bool picked = false;
                            for (int i = 0; i < punters.Length; i++)
                            {
                                if(punters[i].CheckAvailabilityOfCar(cars[number-1]))
                                {
                                    picked = true;
                                    break;
                                }
                            }
                            if (picked)
                            {
                                message = string.Format("Car {0} is in Another Bet, Try With Different Car", number);
                            }
                            else
                            {
                                punters[index].PlaceBet(amount, cars[number - 1]);
                            }
                        }
                        if (message.Length != 0)
                        {
                            MessageBox.Show(message);
                        }
                    }

                    if (punters[index].PunterBet != null)
                    {
                        totalbet++;
                    }
                }
            }
            SetupPunter();
            if (totalbet == active)
            {
                btnOperation.Text = "Start Race...";
                panelBet.Enabled = false;
            }
        }

        private void StartRace()
        {
            timers = new Timer[cars.Length];
            for (int index = 0; index < cars.Length; index++)
            {
                timers[index] = new Timer();
                timers[index].Interval = 12;
                timers[index].Tick += Ticking_Event;
            }
            foreach (Timer timer in timers)
            {
                timer.Start();
            }
            btnOperation.Enabled = false;
        }

        private void Ticking_Event(object sender, EventArgs e)
        {
            Timer timer = (Timer)sender;
            int index = -1;
            for (int i = 0; i < timers.Length; i++)
            {
                if (timer == timers[i])
                {
                    index = i;
                    break;
                }
            }
            if (index != -1)
            {
                if (cars[index].FinishTheRace())
                {
                    
                    if (winnerCar == null)
                    {
                        winnerCar = cars[index];
                    }
                    foreach (Timer tim in timers)
                    {
                        tim.Stop();
                    }
                }
                else
                {
                    int step = new Random().Next(1, 25);
                    cars[index].Move(step);
                }
            }
            
            if (winnerCar != null)
            {
                MessageBox.Show(string.Format("{0} is won the Car Race!!!", winnerCar.CarName));
                SetupPunter();
                for ( index = 0; index < punters.Length; index++)
                {
                    if (punters[index].CheckBetStatus())
                    {
                        punters[index].CheckAndUpdateWinning(winnerCar);
                    }
                }

                winnerCar = null;
                timers = null;
                int inactive = 0;
                for ( index = 0; index < punters.Length; index++)
                {
                    if (punters[index].Busted())
                    {
                        inactive++;
                    }
                    else
                    {
                        RadioButton radio = punters[index].PunterRadioButton;
                        if (radio.Enabled && radio.Checked)
                        {
                            lblMax.Text = string.Format("{0} Max Bet Amount Limit is ${1}", punters[index].Name, punters[index].Cash);
                            btnOperation.Text = string.Format("Place A BET For Player {0}", punters[index].Name);
                            lblBet.Text = string.Format("Bet Amount of {0} is $", punters[index].Name);
                            lblCar.Text = string.Format("{0} Place Bet on Car", punters[index].Name);
                            npBetAmount.Maximum = punters[index].Cash;
                            npBetAmount.Minimum = 1;
                        }
                    }
                    punters[index].ResetBet();
                }                
                if (inactive == punters.Length)
                {
                    MessageBox.Show("ALL PUNTER ARE BUSTED.... GAME OVER!!!!");
                    Application.Exit();
                }
                else
                {
                    panelBet.Enabled = true;
                    btnOperation.Enabled = true;                    
                    SetupPunter();
                }
                
                for ( index = 0; index < cars.Length; index++)
                {
                    cars[index].Reset();
                }
            }
        }

        private void radio_changed(object sender, EventArgs e)
        {
            SetupPunter();
        }

        private void SetupPunter()
        {
            for (int index = 0; index < punters.Length; index++)
            {
                Punter punter = punters[index];
                string message = "";
                if (punter.Busted())
                {
                    message = "Punter BUSTED. No Cash.";
                }
                else
                {
                    if (punter.PunterBet == null)
                    {
                        message = string.Format("{0} hasn't placed a Bet", punter.Name);
                    }
                    else
                    {
                        message = string.Format("{0} placed Bet Amount ${1} on {2}", punter.Name, punter.PunterBet.Amount, punter.PunterBet.Car.CarName);
                    }
                    if (punter.PunterRadioButton.Checked)
                    {
                        lblMax.Text = string.Format("{0} Max Bet Amount Limit is ${1}", punter.Name, punter.Cash);
                        btnOperation.Text = string.Format("Place BET For Player {0}", punter.Name);
                        lblBet.Text = string.Format("Bet Amount of {0} is $", punter.Name);
                        lblCar.Text = string.Format("{0} Place Bet on Car", punter.Name);
                        npBetAmount.Minimum = 1;
                        npBetAmount.Maximum = punter.Cash;
                        npBetAmount.Value = 1;
                    }
                }
                punter.PunterTextBox.Text = message;
            }
        }

        private void GameForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
