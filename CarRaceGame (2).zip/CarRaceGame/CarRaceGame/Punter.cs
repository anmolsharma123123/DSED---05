﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRaceGame
{
    public abstract class Punter
    {
        public int Cash { get; set; }

        public Bet PunterBet { get; set; }

        public RadioButton PunterRadioButton { get; set; }

        public string Name { get; set; }

        public TextBox PunterTextBox { get; set; }

        public bool Busted()
        {
            return Cash <= 0;
        }

        public void UpdateBetText()
        {
            PunterTextBox.Text = PunterBet.Description();
        }

        public void PlaceBet(int amount, Car car)
        {
            PunterBet = new Bet() { Amount = amount, Car = car, Bettor = this };
            UpdateBetText();
        }

        public void ResetBet()
        {
            PunterBet = null;
        }

        public bool CheckAvailabilityOfCar(Car car)
        {
            return PunterBet != null && PunterBet.Car == car;
        }

        public bool CheckBetStatus()
        {
            return PunterBet != null;
        }

        public bool PunterRadionCheckStatus()
        {
            return PunterRadioButton.Checked;
        }

        public void CheckAndUpdateWinning(Car winner)
        {
            string text = "";
            int amount = PunterBet.GetBetAmount(winner);
            Cash += amount;
            if (PunterBet.CheckWinner(winner))
            {
                text = string.Format("{0} won the Race and Now, has ${1} Amount For Bet", Name, Cash);
            }
            else if (Cash == 0)
            {
                text = "Punter Lost all Amount So BUSTED";
                PunterRadioButton.Enabled = false;
            }
            else
            {
                text = string.Format("{0} Lost ${1} Amount in the Race and Now, has ${1} Amount in Hand", Name, PunterBet.Amount, Cash);
            }

            PunterTextBox.Text = text;
        }
    }
}
