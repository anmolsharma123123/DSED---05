﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRaceGame
{
    public class Charlotte : Punter
    {
        public Charlotte()
        {
            Name = "Charlotte";
            Cash = 50;
        }
    }
}
