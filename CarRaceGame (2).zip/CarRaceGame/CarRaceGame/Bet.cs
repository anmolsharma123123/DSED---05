﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRaceGame
{
    public class Bet
    {
        public int Amount { get; set; }

        public Car Car { get; set; }

        public Punter Bettor { get; set; }

        public string Description()
        {
            string description = Bettor.Name + " bet $" + Amount + " on " + Car.CarName;
            return description;
        }

        public int GetBetAmount(Car winner)
        {
            if (winner != Car)
            {
                return -1 * Amount;
            }
            return Amount;
        }

        public bool CheckWinner(Car winner)
        {
            return winner == Car;
        }
    }
}
