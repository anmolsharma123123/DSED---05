﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRaceGame
{
    public class Amelia:Punter
    {
        public Amelia()
        {
            Name = "Amelia";
            Cash = 50;
        }
    }
}
